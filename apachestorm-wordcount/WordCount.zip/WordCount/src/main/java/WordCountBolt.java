import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.storm.task.OutputCollector;
import org.apache.storm.task.TopologyContext;
import org.apache.storm.topology.OutputFieldsDeclarer;
import org.apache.storm.topology.base.BaseRichBolt;
import org.apache.storm.tuple.Fields;
import org.apache.storm.tuple.Tuple;

@SuppressWarnings("serial")
public class WordCountBolt extends BaseRichBolt
{
    private OutputCollector collector;
    private HashMap<String, Long> counts = null;
    int temp_count_variable=0;
    private Connection con;
    private Statement stmt;
    static final String username="root";  //will be external & encrypted in production
    static final String password="123"; //will be external & encrypted in production

    @SuppressWarnings("rawtypes")
	public void prepare(Map config, TopologyContext context, 
            OutputCollector collector) 
    {
    	initializeDBConnection();
    	 
        this.collector = collector;
        this.counts = new HashMap<String, Long>();
    }

    private void initializeDBConnection() {

   	 try 
        {
  		Class.forName("com.mysql.jdbc.Driver");
  		con=DriverManager.getConnection("jdbc:mysql://localhost:3306/WCDB?useSSL=false",username,password);  
  		stmt=con.createStatement(); 
  	} catch ( SQLException e)
        {
  		// TODO Auto-generated catch block
  		e.printStackTrace();
  	}  
        catch (ClassNotFoundException e)
        {
  		// TODO Auto-generated catch block
  		e.printStackTrace();
  	}  
    }
    
    public void execute(Tuple tuple) 
    {
    	temp_count_variable++; //incoming tuple counter
        String word = tuple.getStringByField("word");
        Long count = this.counts.get(word);
        if(count == null)
        {
            count = 0L;
        }
        count++;
        this.counts.put(word, count);
        //this.collector.emit(tuple,new Values(word, count)); //anchoring [Reliability API]
        this.collector.ack(tuple);//acknowledge [Reliability API]
        
        if (temp_count_variable == 100000000) { //Save and Reset on 10000000 tuples
    		temp_count_variable = 0;  //avoid database overload 
    		saveCounts();
    	}
    }
    
    private void saveCounts() {
    	
    	List<String> keys = new ArrayList<String>();
    	keys.addAll(this.counts.keySet());
    	Collections.sort(keys);
    	try {
	    	for (String key : keys)
	        {
	    		Long count = this.counts.get(key);
	    		if(count == null || count.equals(0L))
	    			continue;
		    	//Update or insert in single statement avoids read inconsistencies
		    	String query = "INSERT INTO wordcount "+
		    	"VALUES ('"+key+"', "+count +") "+
		    	"ON DUPLICATE KEY UPDATE "+
		    	"counts = counts + "+count;

				stmt.execute(query);
				//reset the map once previous counts saved for fresh accumulation
	        }
	    	this.counts.clear();
    	} catch (SQLException e) {
			e.printStackTrace();
		}
    }

    public void declareOutputFields(OutputFieldsDeclarer declarer)
    {
        declarer.declare(new Fields("word", "count"));
    }
    
    public void cleanup() {
    	saveCounts();
		try {
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
    }
}