import org.apache.storm.Config;
import org.apache.storm.LocalCluster;
import org.apache.storm.StormSubmitter;
import org.apache.storm.topology.TopologyBuilder;
import org.apache.storm.utils.Utils;


public class WordCountTopology {

    private static final String SENTENCE_SPOUT_ID = "SentenceSpout";
    private static final String SPLIT_BOLT_ID = "SplitSentenceBolt";
    private static final String COUNT_BOLT_ID = "WordCountBolt";


    public static void main(String[] args) throws Exception {

        SentenceSpout spout = new SentenceSpout();
        SplitSentenceBolt splitBolt = new SplitSentenceBolt();
        WordCountBolt countBolt = new WordCountBolt();

        TopologyBuilder builder = new TopologyBuilder();

        //Topology SentenceSpout => SplitSentenceBolt => WordCountBolt
        
        builder.setSpout(SENTENCE_SPOUT_ID, spout,1);

        //Shuffle Grouping = Ensures Uniform Load Distribution
        //Across SplitSentenceBolt 
        builder.setBolt(SPLIT_BOLT_ID, splitBolt,3)
                .shuffleGrouping(SENTENCE_SPOUT_ID);

        //Across WordCountBolt 
        builder.setBolt(COUNT_BOLT_ID, countBolt,4)
                .shuffleGrouping(SPLIT_BOLT_ID);

        Config config = new Config();

    if (args != null && args.length > 0) {
    	//As we are running on a 4 core single machine with 1 task per executor.
    	//Max parallel execution=4 jvm processes
      config.setNumWorkers(4);
  
      StormSubmitter.submitTopologyWithProgressBar(args[0], config, builder.createTopology());
    }
    else {

      LocalCluster cluster = new LocalCluster();
      cluster.submitTopology("test", config, builder.createTopology());
      Utils.sleep(100000);
      cluster.killTopology("test");
      cluster.shutdown();
    }

    }
}